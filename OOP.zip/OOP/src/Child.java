public class Child extends Parent {
    @Override
    public void walk() {
        System.out.println("Child is walking");
    }
}
