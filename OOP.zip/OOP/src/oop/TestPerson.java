package oop;

import java.time.LocalDate;
import java.util.Scanner;

public class TestPerson {
    public static void main(String[] args) throws InterruptedException {
       /* Student doniyor = new Student("Doniyor", "Qalandarov", 22, 66, 177, 4,
                0, 0, 0, 0);
        System.out.printf("Student name is %s\n", doniyor.getName());
        System.out.printf("Student age is %d\n", doniyor.getAge());
        System.out.printf("Student weight is %.1f\n", doniyor.getWeight());
        System.out.printf("Student height is %.1f\n", doniyor.getHeight());
        System.out.printf("Student course is %d\n", doniyor.getCourse());
        doniyor.examStart();
        doniyor.listening();
        Thread.sleep(10000);
        System.out.println("Listening finished");
        doniyor.setListening(6.5);
        System.out.printf("The student's listening score is: %.1f\n", doniyor.getListening());
        System.out.println();
        doniyor.speaking();
        Thread.sleep(10000);
        System.out.println("Speaking finished");
        doniyor.setSpeaking(6.5);
        System.out.printf("The student's speaking score is: %.1f\n", doniyor.getSpeaking());
        System.out.println();
        Thread.sleep(5000);
        doniyor.writing();
        Thread.sleep(10000);
        System.out.println("Writing finished");
        doniyor.setWriting(7);
        System.out.printf("The student's writing score is %.1f", doniyor.getWriting());
        System.out.println();
        Thread.sleep(500);
        System.out.println();
        doniyor.reading();
        Thread.sleep(10000);
        System.out.println("Reading finished");
        doniyor.setReading(7);
        System.out.printf("The student reading score is %.1f\n", doniyor.getReading());
        doniyor.examFinish();
        Thread.sleep(400);
        System.out.println("Overall Band Score: " + doniyor.overallBandScore(doniyor.getWriting(), doniyor.getListening(), doniyor.getSpeaking(),
                doniyor.getReading()));*/
        Abiturient doniyor = new Abiturient("Doniyor","Qalandarov",18,66,177,
                "Qo'shko'pir");
        System.out.printf("Abituriant name is %s\n",doniyor.getName());
        doniyor.setDate(LocalDate.of(1999,7,10));
        System.out.printf("Abiturient birthday %s\n",doniyor.getDate());
        doniyor.setCountry("Qo'shko'pir");
        System.out.printf("Abiturient country %s\n",doniyor.getCountry());
        System.out.println("");
        doniyor.examStart();
        doniyor.math();
        Thread.sleep(7500);
        doniyor.endMath();
        doniyor.setSolved(25);
        System.out.println("Abiturient matematikdan " + doniyor.getSolved() + " ni ishladi");
        System.out.println("Abiturient matematikadan " + doniyor.scoreChooseScience(25)+ " ball oldi\n");
        doniyor.phisics();
        Thread.sleep(7500);
        doniyor.endPyhsics();
        doniyor.setSolved(20);
        System.out.println("Abiturient fizikadan " + doniyor.getSolved()+" ni ishladi");
        System.out.println("Abiturinet fizikadan " + doniyor.scoreChooseScience(20) + " ball oldi\n");
        System.out.println("");
        doniyor.english();
        Thread.sleep(8000);
        Thread.interrupted();
        doniyor.endEnglish();
        doniyor.setSolved(22);
        System.out.println("Abiturient ingliz tilidan " + doniyor.getSolved() + " ni ishladi");
        System.out.println("Abiturient ingliz tilidan " + doniyor.scoreMandatoryScience(22) + " ball oldi");
        doniyor.history();
        Thread.sleep(7000);
        doniyor.endHistory();
        doniyor.setSolved(8);
        System.out.println("Abiturient tarixdan " + doniyor.getSolved() + " ni ishladi");
        System.out.println("Abiturient tarixdan " + doniyor.scoreMandatoryScience(doniyor.getSolved()) + " ball oldi");



    }
}