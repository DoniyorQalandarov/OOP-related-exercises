package oop;

public class Person {
    private String name;
    private String lastName;
    private int age;
    private double weight;
    private double height;
    private String country;

    public Person(String name, String lastName, int age, double weight, double height, String country) {
        this.name = name;
        this.lastName = lastName;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.country = country;
    }

    public Person(String name, String lastName, int age, double weight, double height) {
    }

    public void examStart() {
        System.out.print("Exam started\n");
    }

    public void examFinish() {
        System.out.print("Exam finished\n");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", lastName='" + lastName + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                ", height=" + height +
                ", country='" + country + '\'' +
                '}';
    }

    public void writing() {
        System.out.println("Student is writing");
    }

    public void listening() {
        System.out.println("Student is listening");
    }

    public void speaking() {
        System.out.println("Student is speaking");
    }

    public void reading() {
        System.out.println("Student is  reading");
    }

    public void math() {
        System.out.println("Abiturient matematika ishlayapdi");
    }

    public void phisics() {
        System.out.println("Abiturient fizika ishlayapdi");
    }

    public void english() {
        System.out.println("Abiturient ingiz tili ishlayapdi");
    }

    public void history() {
        System.out.println("Abiturient tarix ishlayapdi");
    }

    public void math2() {
        System.out.println("Abiturient majburiy fanlardan matematikani ishlayapdi");
    }

    public void endMath() {
        System.out.println("Abiturient matematikani ishlab bo'ldi");
    }
    public void endEnglish() {
        System.out.println("Abiturient  ingliz tilini ishlab bo'ldi");
    }
    public void endHistory() {
        System.out.println("Abiturient tarixni ishlab bo'ldi");
    }
    public void endMath2() {
        System.out.println("Abitrient matematikani ishlab bo'ldi");
    }
    public void endPyhsics() {
        System.out.println("Abiturient fizikani ishlab bo'ldi");
    }
}
