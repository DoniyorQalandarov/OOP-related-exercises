public class Parent {
    public void walk() {
        System.out.println("Parent is walking");
    }
}
