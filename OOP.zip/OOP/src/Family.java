public class Family {
    public static void main(String[] args) {
        Parent parent = new Parent();
        parent.walk();
        Parent child = new Child();
        child.walk();
    }
}
