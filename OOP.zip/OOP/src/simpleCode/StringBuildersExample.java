package simpleCode;

public class StringBuildersExample {
    public static void main(String[] args) {
        StringBuilder stringBuilder = new StringBuilder("Salom bugun Chorshanba");
        System.out.println(stringBuilder);
        System.out.println(stringBuilder.append(" kuni"));
    }
}
